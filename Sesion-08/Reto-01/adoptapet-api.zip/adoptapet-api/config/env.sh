export NODE_ENV='development'
export PORT=3000
export SECRET='secret' # para mayor seguridad puedes cambiar esto por el secreto de tu preferencia
export MONGODB_URI='mongodb+srv://introabd:cangetin123@cluster0.kbuns.mongodb.net/AdoptaPet?retryWrites=true&w=majority'